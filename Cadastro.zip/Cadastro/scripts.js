const inputNome = document.getElementById("nome");
const inputSenha = document.getElementById("senha");
const inputEmail = document.getElementById("Email");
const botaoCriar = document.getElementById("botaoCriar");

function salvarCadastro(){
    let nome = inputNome.value;
    let senha = inputSenha.value;
    let email = inputEmail.value;
    localStorage.setItem("nomeUsuario", nome);
    localStorage.setItem("senhaUsuario", senha);
    localStorage.setItem("EmailUsuario", email);
}